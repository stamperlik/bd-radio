import React from "react";
import Radio from "./Radio";

const App: React.FC = () => {
  return (
    <>
      <Radio />
    </>
  );
};

export default App;
